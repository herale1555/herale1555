import React, { useRef, useState } from "react";

export default function App() {
  const [mediaSrc, setMediaSrc] = useState("");
  const [mediaType, setMediaType] = useState("audio");
  const fileInputRef = useRef();

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    setMediaSrc(url);
    if (file.type.startsWith("video")) setMediaType("video");
    else setMediaType("audio");
  };

  const handleOpen = () => {
    fileInputRef.current.click();
  };

  return (
    <div style={{ maxWidth: 500, margin: "2em auto", fontFamily: "sans-serif", textAlign: "center" }}>
      <h1>Simple Media Player</h1>
      <input
        type="file"
        accept="audio/*,video/*"
        ref={fileInputRef}
        style={{ display: "none" }}
        onChange={handleFileChange}
      />
      <button onClick={handleOpen} style={{ margin: "1em" }}>
        Choose Audio/Video File
      </button>
      <div style={{ margin: "2em 0" }}>
        {mediaSrc && mediaType === "audio" && (
          <audio controls src={mediaSrc} style={{ width: "100%" }}>
            Your browser does not support the audio element.
          </audio>
        )}
        {mediaSrc && mediaType === "video" && (
          <video controls src={mediaSrc} style={{ width: "100%" }}>
            Your browser does not support the video element.
          </video>
        )}
      </div>
    </div>
  );
}